"""
Script to generate a realistic F1 historical race dataset for training the predictor model.
This creates a CSV file with race data including drivers, constructors, tracks, weather, and results.
"""

import pandas as pd
import random
import os

# Define F1 drivers, constructors, and tracks
drivers = [
    "Lewis Hamilton", "Max Verstappen", "Charles Leclerc", "Sergio Perez",
    "Carlos Sainz", "George Russell", "Lando Norris", "Fernando Alonso",
    "Esteban Ocon", "Pierre Gasly", "Valtteri Bottas", "Zhou Guanyu",
    "Kevin Magnussen", "Nico Hulkenberg", "Yuki Tsunoda", "Daniel Ricciardo",
    "Alex Albon", "Logan Sargeant", "Lance Stroll", "Oscar Piastri"
]

constructors = [
    "Mercedes", "Red Bull Racing", "Ferrari", "McLaren", "Aston Martin",
    "Alpine", "Alfa Romeo", "Haas", "AlphaTauri", "Williams"
]

tracks = [
    "Bahrain International Circuit", "Jeddah Corniche Circuit", "Albert Park Circuit",
    "Baku City Circuit", "Miami International Autodrome", "Monaco Street Circuit",
    "Circuit de Barcelona-Catalunya", "Circuit Gilles Villeneuve", "Red Bull Ring",
    "Silverstone Circuit", "Hungaroring", "Circuit de Spa-Francorchamps",
    "Circuit Zandvoort", "Monza", "Marina Bay Street Circuit", "Suzuka Circuit",
    "Losail International Circuit", "Circuit of the Americas", "Autodromo Hermanos Rodriguez",
    "Interlagos", "Las Vegas Street Circuit", "Yas Marina Circuit"
]

weather_conditions = ["Dry", "Rain", "Cloudy", "Wet"]

# Driver-Constructor pairings (realistic 2023-2024 pairings)
driver_team_mapping = {
    "Lewis Hamilton": "Mercedes",
    "George Russell": "Mercedes",
    "Max Verstappen": "Red Bull Racing",
    "Sergio Perez": "Red Bull Racing",
    "Charles Leclerc": "Ferrari",
    "Carlos Sainz": "Ferrari",
    "Lando Norris": "McLaren",
    "Oscar Piastri": "McLaren",
    "Fernando Alonso": "Aston Martin",
    "Lance Stroll": "Aston Martin",
    "Pierre Gasly": "Alpine",
    "Esteban Ocon": "Alpine",
    "Valtteri Bottas": "Alfa Romeo",
    "Zhou Guanyu": "Alfa Romeo",
    "Kevin Magnussen": "Haas",
    "Nico Hulkenberg": "Haas",
    "Yuki Tsunoda": "AlphaTauri",
    "Daniel Ricciardo": "AlphaTauri",
    "Alex Albon": "Williams",
    "Logan Sargeant": "Williams"
}

# Create performance ratings for drivers (used to simulate realistic results)
driver_performance = {
    "Max Verstappen": 95,
    "Lewis Hamilton": 92,
    "Charles Leclerc": 88,
    "Fernando Alonso": 87,
    "George Russell": 86,
    "Carlos Sainz": 85,
    "Sergio Perez": 84,
    "Lando Norris": 83,
    "Oscar Piastri": 80,
    "Pierre Gasly": 78,
    "Esteban Ocon": 77,
    "Lance Stroll": 75,
    "Valtteri Bottas": 74,
    "Alex Albon": 73,
    "Nico Hulkenberg": 72,
    "Zhou Guanyu": 70,
    "Yuki Tsunoda": 69,
    "Kevin Magnussen": 68,
    "Daniel Ricciardo": 67,
    "Logan Sargeant": 65
}

def generate_race_data():
    """Generate realistic F1 race data"""
    races = []
    race_id = 1
    
    # Generate data for multiple seasons (2021-2024)
    for season in range(2021, 2025):
        for track in tracks[:20]:  # 20 races per season
            # Random number of laps (realistic for each track)
            total_laps = random.randint(50, 70)
            weather = random.choice(weather_conditions)
            
            # Shuffle drivers for starting grid
            race_drivers = drivers.copy()
            random.shuffle(race_drivers)
            
            # Assign grid positions
            grid_positions = list(range(1, 21))
            
            for i, driver in enumerate(race_drivers):
                grid_position = grid_positions[i]
                constructor = driver_team_mapping[driver]
                
                # Calculate race performance based on driver skill, grid position, and randomness
                performance_score = driver_performance[driver]
                grid_bonus = (21 - grid_position) * 2  # Better grid = higher bonus
                weather_factor = random.randint(-5, 5)
                
                # Rain can be an equalizer
                if weather in ["Rain", "Wet"]:
                    weather_factor = random.randint(-10, 10)
                
                final_score = performance_score + grid_bonus + weather_factor
                
                races.append({
                    'race_id': race_id,
                    'season': season,
                    'track': track,
                    'driver': driver,
                    'constructor': constructor,
                    'grid': grid_position,
                    'weather': weather,
                    'laps': total_laps,
                    'performance_score': final_score
                })
            
            race_id += 1
    
    return races

# Generate the dataset
print("Generating F1 race dataset...")
race_data = generate_race_data()
df = pd.DataFrame(race_data)

# Determine race winner (highest performance score in each race)
df['position'] = df.groupby('race_id')['performance_score'].rank(ascending=False, method='first')
df['winner'] = (df['position'] == 1).astype(int)

# Sort by race_id and position
df = df.sort_values(['race_id', 'position'])

# Drop performance_score as it's only for simulation
df = df.drop('performance_score', axis=1)

# Create dataset directory if it doesn't exist
os.makedirs('dataset', exist_ok=True)

# Save to CSV
output_file = 'dataset/f1_race_data.csv'
df.to_csv(output_file, index=False)

print(f"Dataset created successfully: {output_file}")
print(f"Total races: {race_id - 1}")
print(f"Total records: {len(df)}")
print("\nDataset preview:")
print(df.head(10))
print("\nDataset info:")
print(df.info())
print("\nWinner distribution:")
print(df[df['winner'] == 1]['driver'].value_counts().head(10))
