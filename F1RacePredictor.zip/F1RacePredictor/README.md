# 🏎️ F1 Race Outcome Predictor

A beginner-friendly machine learning project that predicts Formula 1 race winners and podium finishes using historical race data. Built with Python, scikit-learn, and Streamlit.

![F1 Predictor](https://img.shields.io/badge/F1-Predictor-E10600?style=for-the-badge)
![Python](https://img.shields.io/badge/Python-3.11-blue?style=for-the-badge)
![Streamlit](https://img.shields.io/badge/Streamlit-1.28-red?style=for-the-badge)
![scikit-learn](https://img.shields.io/badge/scikit--learn-ML-orange?style=for-the-badge)

## 📋 Table of Contents

- [Overview](#overview)
- [Features](#features)
- [Dataset](#dataset)
- [Installation](#installation)
- [Usage](#usage)
- [How It Works](#how-it-works)
- [Project Structure](#project-structure)
- [Model Performance](#model-performance)
- [Screenshots](#screenshots)
- [Future Improvements](#future-improvements)
- [Contributing](#contributing)

## 🎯 Overview

This project uses a **Random Forest Classifier** to predict F1 race outcomes based on various factors including:
- 🏁 Track/Circuit
- 🌤️ Weather conditions
- 🎯 Grid position (qualifying results)
- 👤 Driver
- 🏎️ Constructor (team)
- 🔄 Number of laps

The application provides an interactive web interface built with Streamlit where users can input race parameters and receive predictions for the race winner and top 3 podium finishers with confidence probabilities.

## ✨ Features

### Core Features
- ✅ **Race Winner Prediction**: Predict the most likely winner with confidence percentage
- ✅ **Podium Predictions**: Get top 3 predicted finishers
- ✅ **Interactive Web Interface**: User-friendly Streamlit dashboard
- ✅ **Historical Statistics**: View track-specific historical data and trends
- ✅ **Feature Importance Visualization**: Understand which factors matter most
- ✅ **Detailed Probability Rankings**: See probability scores for top 10 drivers

### Technical Features
- 📊 Data preprocessing with categorical encoding
- 🤖 Random Forest machine learning model
- 💾 Model persistence using pickle
- 📈 Comprehensive model evaluation metrics
- 🎨 Beautiful visualizations with matplotlib and seaborn
- ⚡ Cached model loading for fast predictions

## 📊 Dataset

The project includes a sample dataset with realistic F1 race data:

- **Time Period**: 2021-2024 seasons
- **Races**: 80 races across 20+ circuits
- **Drivers**: 20 current F1 drivers
- **Constructors**: 10 teams
- **Features**: Track, driver, constructor, grid position, weather, laps, race outcome

### Dataset Structure

| Column | Description | Type |
|--------|-------------|------|
| race_id | Unique race identifier | Integer |
| season | Racing season year | Integer |
| track | Circuit name | String |
| driver | Driver name | String |
| constructor | Team name | String |
| grid | Starting grid position | Integer (1-20) |
| weather | Weather condition | Categorical |
| laps | Number of race laps | Integer |
| position | Finishing position | Integer |
| winner | Binary target (1=winner, 0=non-winner) | Binary |

**Note**: You can replace the sample dataset with your own CSV data containing the same columns.

## 🚀 Installation

### Prerequisites
- Python 3.11 or higher
- pip package manager

### Quick Start

1. **Clone the repository**
```bash
git clone <your-repo-url>
cd f1-race-predictor
```

2. **Install dependencies**
```bash
pip install pandas numpy scikit-learn streamlit matplotlib seaborn
```

Or if you have a requirements file:
```bash
pip install -r requirements.txt
```

3. **Generate the dataset** (if needed)
```bash
python create_dataset.py
```

4. **Train the model**
```bash
python model.py
```

5. **Run the Streamlit app**
```bash
streamlit run app.py --server.port 5000
```

6. **Open your browser**
Navigate to: `http://localhost:5000`

## 💻 Usage

### Training the Model

Run the model training script to preprocess data and train the Random Forest classifier:

```bash
python model.py
```

This will:
- Load the F1 race dataset
- Preprocess and encode features
- Train a Random Forest model
- Evaluate model performance
- Save the trained model to `models/f1_predictor_model.pkl`
- Generate feature importance visualizations

### Running the Web App

Launch the Streamlit application:

```bash
streamlit run app.py --server.port 5000
```

### Making Predictions

1. **Select Race Parameters** (in the sidebar):
   - Choose a track from the dropdown
   - Select weather conditions (Dry, Rain, Cloudy, Wet)
   - Enter grid position (1-20)
   - Optionally select specific driver and constructor

2. **Click "Predict Winner"**

3. **View Results**:
   - Predicted race winner with confidence percentage
   - Top 3 podium finishers
   - Detailed probability rankings for top 10 drivers

### Example Usage

**Input:**
- Track: Monza
- Weather: Dry
- Grid Position: 5
- Driver: Auto-predict
- Laps: 53

**Output:**
- 🥇 Winner: Max Verstappen (85.3% confidence)
- 🥈 2nd Place: Lewis Hamilton (12.7%)
- 🥉 3rd Place: Charles Leclerc (8.9%)

## 🔧 How It Works

### 1. Data Preprocessing
- Categorical variables (driver, constructor, track, weather) are encoded using `LabelEncoder`
- Features are normalized and prepared for machine learning
- Target variable is binary: winner (1) or non-winner (0)

### 2. Model Training
- **Algorithm**: Random Forest Classifier
- **Parameters**:
  - 200 estimators (trees)
  - Max depth: 15
  - Class weights: Balanced (handles imbalanced data)
- **Train-Test Split**: 80-20 with stratification

### 3. Prediction
- User inputs are encoded using the same encoders
- Model predicts win probability for all drivers
- Results are ranked by probability
- Top predictions are displayed with confidence scores

### 4. Evaluation
- Accuracy metrics on training and test sets
- Confusion matrix visualization
- Feature importance analysis
- Classification report with precision, recall, F1-score

## 📁 Project Structure

```
f1-race-predictor/
│
├── dataset/
│   └── f1_race_data.csv          # Historical F1 race data
│
├── models/
│   └── f1_predictor_model.pkl    # Trained model with encoders
│
├── visualizations/
│   ├── feature_importance.png    # Feature importance chart
│   └── confusion_matrix.png      # Model confusion matrix
│
├── create_dataset.py             # Dataset generation script
├── model.py                      # Model training script
├── app.py                        # Streamlit web application
├── requirements.txt              # Python dependencies
└── README.md                     # Project documentation
```

## 📈 Model Performance

The Random Forest model achieves strong performance on the test dataset:

- **Accuracy**: ~85-90% (varies based on dataset)
- **Precision**: High precision for winner class
- **Recall**: Good recall with balanced class weights
- **F1-Score**: Strong overall F1-score

### Feature Importance

The model learns which features are most predictive:
1. **Grid Position** - Starting position is highly influential
2. **Driver** - Individual driver skill matters significantly
3. **Constructor** - Team performance is crucial
4. **Track** - Circuit characteristics affect outcomes
5. **Weather** - Weather can be a game-changer
6. **Laps** - Race distance has some impact

## 🖼️ Screenshots

### Main Prediction Interface
*Interactive dashboard with race configuration and real-time predictions*

### Track Statistics
*Historical performance analysis for each circuit*

### Feature Importance
*Visualization showing which factors most influence race outcomes*

## 🚀 Future Improvements

Potential enhancements for the project:

- [ ] Add more historical data (earlier seasons)
- [ ] Include additional features (tire strategy, pit stops, safety cars)
- [ ] Implement neural network models for comparison
- [ ] Add live race data integration via API
- [ ] Create downloadable prediction reports
- [ ] Add driver and constructor performance trends
- [ ] Implement model retraining interface
- [ ] Add more detailed track-specific analytics
- [ ] Include qualification predictions
- [ ] Add championship standings forecasting

## 🤝 Contributing

Contributions are welcome! Here's how you can help:

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📝 License

This project is open source and available for educational purposes.

## 🙏 Acknowledgments

- Formula 1 for the exciting sport
- scikit-learn for the excellent ML library
- Streamlit for the amazing web framework
- The F1 community for inspiration

## 📧 Contact

For questions or feedback, please open an issue on GitHub.

---

**Built with ❤️ for F1 fans and data science enthusiasts**

🏁 Happy Predicting! 🏎️
