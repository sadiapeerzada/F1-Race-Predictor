"""
F1 Race Outcome Predictor - Streamlit Web Application

Interactive web app to predict F1 race winners and podium finishes based on
track, weather, grid position, driver, and constructor selections.
"""

import streamlit as st
import pandas as pd
import numpy as np
import pickle
import os
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime

# Page configuration
st.set_page_config(
    page_title="F1 Race Outcome Predictor",
    page_icon="🏎️",
    layout="wide"
)

# Custom CSS for better styling
st.markdown("""
    <style>
    .main-header {
        font-size: 3rem;
        color: #E10600;
        text-align: center;
        font-weight: bold;
        margin-bottom: 0;
    }
    .sub-header {
        font-size: 1.2rem;
        text-align: center;
        color: #666;
        margin-top: 0;
    }
    .prediction-box {
        background-color: #f0f2f6;
        padding: 20px;
        border-radius: 10px;
        border-left: 5px solid #E10600;
    }
    .winner-text {
        font-size: 2rem;
        color: #E10600;
        font-weight: bold;
    }
    .podium-text {
        font-size: 1.3rem;
        font-weight: bold;
    }
    </style>
""", unsafe_allow_html=True)

@st.cache_resource
def load_model():
    """
    Load the trained model, encoders, and feature names from pickle file.
    Uses caching to avoid reloading on every interaction.
    
    Returns:
        tuple: (model, encoders, feature_names) or (None, None, None) if not found
    """
    model_path = 'models/f1_predictor_model.pkl'
    
    if not os.path.exists(model_path):
        return None, None, None
    
    try:
        with open(model_path, 'rb') as f:
            model_data = pickle.load(f)
        
        return model_data['model'], model_data['encoders'], model_data['feature_names']
    except Exception as e:
        st.error(f"Error loading model: {str(e)}")
        return None, None, None

@st.cache_data
def load_dataset():
    """
    Load the original dataset for historical statistics.
    Uses caching for performance.
    
    Returns:
        pd.DataFrame: The F1 race dataset
    """
    dataset_path = 'dataset/f1_race_data.csv'
    
    if not os.path.exists(dataset_path):
        return None
    
    return pd.read_csv(dataset_path)

@st.cache_data
def get_driver_constructor_mapping():
    """
    Get the mapping between drivers and their constructors from the dataset.
    Uses the most recent constructor for each driver.
    
    Returns:
        dict: Dictionary mapping driver name to constructor name
    """
    df = load_dataset()
    if df is None:
        return {}
    
    # Get the most recent constructor for each driver (from latest season)
    latest_season = df['season'].max()
    latest_data = df[df['season'] == latest_season]
    
    # Create driver to constructor mapping
    driver_constructor_map = {}
    for _, row in latest_data[['driver', 'constructor']].drop_duplicates().iterrows():
        driver_constructor_map[row['driver']] = row['constructor']
    
    return driver_constructor_map

def get_top_predictions(model, encoders, feature_values, selected_constructor=None, top_n=3):
    """
    Get top N predicted winners with their probabilities.
    For each driver, uses their actual constructor from the dataset unless overridden.
    
    Args:
        model: Trained model
        encoders: Dictionary of label encoders
        feature_values: Dictionary of feature values (without constructor)
        selected_constructor: Optional constructor name to use for all drivers
        top_n: Number of top predictions to return
        
    Returns:
        list: List of tuples (driver_name, probability)
    """
    predictions = []
    driver_encoder = encoders['driver']
    constructor_encoder = encoders['constructor']
    
    # Get driver-constructor mapping
    driver_constructor_map = get_driver_constructor_mapping()
    
    # Get all possible drivers
    all_drivers = list(driver_encoder.classes_)
    
    # For each driver, calculate probability of winning
    for driver in all_drivers:
        # Create feature vector
        try:
            driver_encoded = driver_encoder.transform([driver])[0]
        except:
            continue
        
        # Determine constructor for this driver
        if selected_constructor and selected_constructor != 'Auto-predict':
            # User manually selected a constructor
            constructor = selected_constructor
        else:
            # Use the driver's actual constructor from the dataset
            constructor = driver_constructor_map.get(driver)
            if constructor is None:
                # Fallback if driver not in mapping (shouldn't happen)
                continue
        
        # Encode the constructor
        try:
            constructor_encoded = constructor_encoder.transform([constructor])[0]
        except:
            # Constructor not in training data
            continue
            
        features = [
            feature_values['grid'],
            feature_values['laps'],
            driver_encoded,
            constructor_encoded,
            feature_values['track_encoded'],
            feature_values['weather_encoded']
        ]
        
        # Get probability of winning
        prob = model.predict_proba([features])[0][1]  # Probability of class 1 (winner)
        predictions.append((driver, prob))
    
    # Sort by probability and return top N
    predictions.sort(key=lambda x: x[1], reverse=True)
    return predictions[:top_n]

def plot_track_statistics(df, track_name):
    """
    Plot historical statistics for a specific track.
    
    Args:
        df: Dataset
        track_name: Name of the track
    """
    if df is None:
        st.warning("Dataset not available for historical statistics.")
        return
    
    track_data = df[df['track'] == track_name]
    
    if len(track_data) == 0:
        st.warning(f"No historical data available for {track_name}")
        return
    
    st.subheader(f"📊 Historical Statistics for {track_name}")
    
    col1, col2 = st.columns(2)
    
    with col1:
        # Winner distribution at this track
        winners = track_data[track_data['winner'] == 1]['driver'].value_counts().head(10)
        
        if len(winners) > 0:
            fig, ax = plt.subplots(figsize=(10, 6))
            winners.plot(kind='barh', ax=ax, color='#E10600')
            ax.set_xlabel('Number of Wins')
            ax.set_ylabel('Driver')
            ax.set_title(f'Most Successful Drivers at {track_name}')
            plt.tight_layout()
            st.pyplot(fig)
            plt.close()
    
    with col2:
        # Constructor performance at this track
        constructor_wins = track_data[track_data['winner'] == 1]['constructor'].value_counts().head(10)
        
        if len(constructor_wins) > 0:
            fig, ax = plt.subplots(figsize=(10, 6))
            constructor_wins.plot(kind='barh', ax=ax, color='#0090D0')
            ax.set_xlabel('Number of Wins')
            ax.set_ylabel('Constructor')
            ax.set_title(f'Most Successful Constructors at {track_name}')
            plt.tight_layout()
            st.pyplot(fig)
            plt.close()
    
    # Weather impact at this track
    st.subheader("🌤️ Weather Conditions Impact")
    weather_stats = track_data.groupby('weather').agg({
        'winner': 'sum',
        'race_id': 'count'
    }).rename(columns={'winner': 'Total Races with Winners', 'race_id': 'Total Races'})
    st.dataframe(weather_stats, width='stretch')

def show_feature_importance():
    """
    Display feature importance visualization if available.
    """
    importance_path = 'visualizations/feature_importance.png'
    
    if os.path.exists(importance_path):
        st.subheader("🎯 Feature Importance Analysis")
        st.image(importance_path)
        st.caption("This shows which factors have the most influence on predicting race winners.")

def main():
    """
    Main function to run the Streamlit app.
    """
    # Header
    st.markdown('<p class="main-header">🏎️ F1 Race Outcome Predictor</p>', unsafe_allow_html=True)
    st.markdown('<p class="sub-header">Predict race winners and podium finishes using machine learning</p>', unsafe_allow_html=True)
    
    st.markdown("---")
    
    # Load model and data
    model, encoders, feature_names = load_model()
    df = load_dataset()
    
    # Check if model exists
    if model is None:
        st.error("⚠️ Model not found! Please train the model first by running: `python model.py`")
        st.info("📝 Instructions:\n1. Run `python model.py` to train the model\n2. Refresh this page\n3. Start making predictions!")
        return
    
    st.success("✅ Model loaded successfully!")
    
    # Sidebar for user inputs
    st.sidebar.header("🏁 Race Configuration")
    st.sidebar.markdown("Select race parameters to predict the outcome:")
    
    # Get unique values from encoders
    all_tracks = list(encoders['track'].classes_)
    all_weather = list(encoders['weather'].classes_)
    all_drivers = list(encoders['driver'].classes_)
    all_constructors = list(encoders['constructor'].classes_)
    
    # User inputs
    selected_track = st.sidebar.selectbox(
        "🏁 Select Track:",
        options=sorted(all_tracks),
        help="Choose the F1 circuit"
    )
    
    selected_weather = st.sidebar.selectbox(
        "🌤️ Weather Condition:",
        options=all_weather,
        help="Select the weather condition"
    )
    
    grid_position = st.sidebar.number_input(
        "🎯 Grid Position:",
        min_value=1,
        max_value=20,
        value=5,
        help="Starting position on the grid (1-20)"
    )
    
    # Optional: Driver and Constructor selection
    st.sidebar.markdown("---")
    st.sidebar.markdown("**Optional Parameters:**")
    
    selected_driver = st.sidebar.selectbox(
        "👤 Select Driver (Optional):",
        options=['Auto-predict'] + sorted(all_drivers),
        help="Leave as 'Auto-predict' to find the most likely winner"
    )
    
    selected_constructor = st.sidebar.selectbox(
        "🏎️ Select Constructor (Optional):",
        options=['Auto-predict'] + sorted(all_constructors),
        help="Leave as 'Auto-predict' to find the most likely winner"
    )
    
    # Estimate laps based on typical track data
    if df is not None:
        track_laps = df[df['track'] == selected_track]['laps']
        avg_laps = int(track_laps.mean()) if len(track_laps) > 0 else 60
    else:
        avg_laps = 60
    
    laps = st.sidebar.number_input(
        "🔄 Number of Laps:",
        min_value=40,
        max_value=80,
        value=avg_laps,
        help="Total race laps"
    )
    
    # Prediction button
    st.sidebar.markdown("---")
    predict_button = st.sidebar.button("🚀 Predict Winner", type="primary")
    
    # Main content area
    tab1, tab2, tab3 = st.tabs(["🏆 Predictions", "📊 Track Statistics", "🎯 Model Insights"])
    
    with tab1:
        if predict_button:
            # Encode categorical features
            track_encoded = encoders['track'].transform([selected_track])[0]
            weather_encoded = encoders['weather'].transform([selected_weather])[0]
            
            # Prepare feature values (without constructor - it will be looked up per driver)
            feature_values = {
                'grid': grid_position,
                'laps': laps,
                'track_encoded': track_encoded,
                'weather_encoded': weather_encoded
            }
            
            # Get predictions
            with st.spinner("🔮 Analyzing race data and making predictions..."):
                top_predictions = get_top_predictions(
                    model, 
                    encoders, 
                    feature_values, 
                    selected_constructor=selected_constructor,
                    top_n=3
                )
            
            # Check if we got valid predictions
            if not top_predictions or len(top_predictions) == 0:
                st.error("⚠️ Unable to generate predictions. Please ensure the dataset is available and valid.")
                st.info("Try running `python create_dataset.py` to regenerate the dataset, then `python model.py` to retrain the model.")
            else:
                # Display predictions
                st.markdown('<div class="prediction-box">', unsafe_allow_html=True)
                
                st.markdown("### 🏆 Race Prediction Results")
                
                # Winner prediction
                winner, winner_prob = top_predictions[0]
                st.markdown(f'<p class="winner-text">🥇 Predicted Winner: {winner}</p>', unsafe_allow_html=True)
                st.markdown(f"**Confidence:** {winner_prob*100:.2f}%")
                
                # Progress bar for confidence
                st.progress(winner_prob)
                
                st.markdown("---")
                
                # Podium predictions
                st.markdown('<p class="podium-text">🏁 Predicted Podium Finish:</p>', unsafe_allow_html=True)
                
                col1, col2, col3 = st.columns(3)
                
                with col1:
                    st.markdown("### 🥇 1st Place")
                    st.markdown(f"**{top_predictions[0][0]}**")
                    st.markdown(f"Probability: {top_predictions[0][1]*100:.2f}%")
                
                with col2:
                    st.markdown("### 🥈 2nd Place")
                    st.markdown(f"**{top_predictions[1][0]}**")
                    st.markdown(f"Probability: {top_predictions[1][1]*100:.2f}%")
                
                with col3:
                    st.markdown("### 🥉 3rd Place")
                    st.markdown(f"**{top_predictions[2][0]}**")
                    st.markdown(f"Probability: {top_predictions[2][1]*100:.2f}%")
                
                st.markdown('</div>', unsafe_allow_html=True)
                
                # Show top 10 predictions in detail
                st.markdown("---")
                st.subheader("📋 Detailed Probability Rankings")
                
                top_10 = top_predictions[:10]
                prob_df = pd.DataFrame(top_10, columns=['Driver', 'Win Probability'])
                prob_df['Win Probability'] = prob_df['Win Probability'].apply(lambda x: f"{x*100:.2f}%")
                prob_df.index = range(1, len(prob_df) + 1)
                
                st.dataframe(prob_df, width='stretch')
            
        else:
            st.info("👈 Configure race parameters in the sidebar and click 'Predict Winner' to see predictions!")
            
            # Show example
            st.markdown("### 📝 Example Prediction")
            st.markdown("""
            **Sample Input:**
            - Track: Monza
            - Weather: Dry
            - Grid Position: 5
            
            **Sample Output:**
            - 🥇 Winner: Max Verstappen (85% confidence)
            - 🥈 2nd Place: Lewis Hamilton
            - 🥉 3rd Place: Charles Leclerc
            """)
    
    with tab2:
        if selected_track:
            plot_track_statistics(df, selected_track)
        else:
            st.info("Select a track from the sidebar to view historical statistics.")
    
    with tab3:
        show_feature_importance()
        
        st.markdown("---")
        st.subheader("ℹ️ About This Predictor")
        st.markdown("""
        This F1 Race Outcome Predictor uses a **Random Forest Classifier** trained on historical race data.
        
        **Features used for prediction:**
        - 🎯 Grid Position (qualifying result)
        - 🔄 Number of Laps
        - 👤 Driver
        - 🏎️ Constructor (team)
        - 🏁 Track/Circuit
        - 🌤️ Weather Conditions
        
        **How it works:**
        1. Historical race data is analyzed to find patterns
        2. The model learns which factors lead to race wins
        3. Given new race parameters, it predicts the most likely winner
        4. Probabilities are calculated for all drivers
        
        **Accuracy:** The model is evaluated on historical data with detailed metrics available in the training logs.
        """)

if __name__ == "__main__":
    main()
