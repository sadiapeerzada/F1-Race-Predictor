"""
F1 Race Outcome Predictor - Model Training Script

This script loads historical F1 race data, preprocesses features, trains a Random Forest
Classifier to predict race winners, and saves the trained model for use in the Streamlit app.
"""

import pandas as pd
import numpy as np
import pickle
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns
import os

def load_data(filepath='dataset/f1_race_data.csv'):
    """
    Load F1 race data from CSV file.
    
    Args:
        filepath (str): Path to the CSV file
        
    Returns:
        pd.DataFrame: Loaded dataset
    """
    print("Loading dataset...")
    df = pd.read_csv(filepath)
    print(f"Dataset loaded successfully: {len(df)} records")
    return df

def explore_data(df):
    """
    Explore and display basic information about the dataset.
    
    Args:
        df (pd.DataFrame): The dataset to explore
    """
    print("\n" + "="*80)
    print("DATASET EXPLORATION")
    print("="*80)
    
    print("\nFirst 5 rows:")
    print(df.head())
    
    print("\nDataset Info:")
    print(df.info())
    
    print("\nDataset Shape:", df.shape)
    
    print("\nMissing Values:")
    print(df.isnull().sum())
    
    print("\nUnique values per column:")
    for col in df.columns:
        print(f"{col}: {df[col].nunique()} unique values")
    
    print("\nRace winners distribution (Top 10):")
    winners = df[df['winner'] == 1]['driver'].value_counts().head(10)
    print(winners)
    
    print("\nWeather distribution:")
    print(df['weather'].value_counts())
    
    print("\nTrack distribution (Top 10):")
    print(df['track'].value_counts().head(10))

def preprocess_data(df):
    """
    Preprocess the dataset for machine learning:
    - Encode categorical variables (driver, constructor, track, weather)
    - Prepare features (X) and target (y)
    - Create label encoders for later use in predictions
    
    Args:
        df (pd.DataFrame): Raw dataset
        
    Returns:
        tuple: (X, y, encoders_dict, feature_names)
    """
    print("\n" + "="*80)
    print("DATA PREPROCESSING")
    print("="*80)
    
    # Create a copy to avoid modifying original data
    df_processed = df.copy()
    
    # Initialize dictionary to store encoders
    encoders = {}
    
    # Encode categorical variables
    categorical_features = ['driver', 'constructor', 'track', 'weather']
    
    for feature in categorical_features:
        print(f"Encoding {feature}...")
        encoder = LabelEncoder()
        df_processed[f'{feature}_encoded'] = encoder.fit_transform(df_processed[feature])
        encoders[feature] = encoder
    
    # Select features for the model
    # We use: grid position, laps, and encoded categorical variables
    feature_columns = ['grid', 'laps', 'driver_encoded', 'constructor_encoded', 
                      'track_encoded', 'weather_encoded']
    
    X = df_processed[feature_columns]
    y = df_processed['winner']
    
    print(f"\nFeatures shape: {X.shape}")
    print(f"Target shape: {y.shape}")
    print(f"\nFeature columns: {feature_columns}")
    print(f"\nTarget distribution:")
    print(f"Winners (1): {sum(y == 1)}")
    print(f"Non-winners (0): {sum(y == 0)}")
    
    return X, y, encoders, feature_columns

def train_model(X, y):
    """
    Split data and train a Random Forest Classifier.
    
    Args:
        X (pd.DataFrame): Features
        y (pd.Series): Target variable
        
    Returns:
        tuple: (trained_model, X_train, X_test, y_train, y_test)
    """
    print("\n" + "="*80)
    print("MODEL TRAINING")
    print("="*80)
    
    # Split data into training and testing sets (80-20 split)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    
    print(f"\nTraining set size: {len(X_train)}")
    print(f"Testing set size: {len(X_test)}")
    
    # Initialize Random Forest Classifier
    # Using balanced class weights to handle imbalanced data (more non-winners than winners)
    print("\nTraining Random Forest Classifier...")
    model = RandomForestClassifier(
        n_estimators=200,
        max_depth=15,
        min_samples_split=10,
        min_samples_leaf=5,
        class_weight='balanced',
        random_state=42,
        n_jobs=-1
    )
    
    # Train the model
    model.fit(X_train, y_train)
    print("Model training completed!")
    
    return model, X_train, X_test, y_train, y_test

def evaluate_model(model, X_train, X_test, y_train, y_test, feature_names):
    """
    Evaluate model performance and display metrics.
    
    Args:
        model: Trained model
        X_train, X_test: Training and testing features
        y_train, y_test: Training and testing targets
        feature_names: List of feature names
    """
    print("\n" + "="*80)
    print("MODEL EVALUATION")
    print("="*80)
    
    # Make predictions
    y_train_pred = model.predict(X_train)
    y_test_pred = model.predict(X_test)
    
    # Calculate accuracy
    train_accuracy = accuracy_score(y_train, y_train_pred)
    test_accuracy = accuracy_score(y_test, y_test_pred)
    
    print(f"\nTraining Accuracy: {train_accuracy:.4f} ({train_accuracy*100:.2f}%)")
    print(f"Testing Accuracy: {test_accuracy:.4f} ({test_accuracy*100:.2f}%)")
    
    print("\nClassification Report (Test Set):")
    print(classification_report(y_test, y_test_pred, target_names=['Non-Winner', 'Winner']))
    
    # Feature importance
    print("\nFeature Importance:")
    feature_importance = pd.DataFrame({
        'feature': feature_names,
        'importance': model.feature_importances_
    }).sort_values('importance', ascending=False)
    print(feature_importance)
    
    # Visualize feature importance
    plt.figure(figsize=(10, 6))
    plt.barh(feature_importance['feature'], feature_importance['importance'])
    plt.xlabel('Importance')
    plt.ylabel('Feature')
    plt.title('Feature Importance in F1 Race Winner Prediction')
    plt.tight_layout()
    
    # Create visualizations directory if it doesn't exist
    os.makedirs('visualizations', exist_ok=True)
    plt.savefig('visualizations/feature_importance.png', dpi=300, bbox_inches='tight')
    print("\nFeature importance plot saved to: visualizations/feature_importance.png")
    plt.close()
    
    # Confusion matrix
    cm = confusion_matrix(y_test, y_test_pred)
    plt.figure(figsize=(8, 6))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
                xticklabels=['Non-Winner', 'Winner'],
                yticklabels=['Non-Winner', 'Winner'])
    plt.ylabel('Actual')
    plt.xlabel('Predicted')
    plt.title('Confusion Matrix - F1 Race Winner Prediction')
    plt.tight_layout()
    plt.savefig('visualizations/confusion_matrix.png', dpi=300, bbox_inches='tight')
    print("Confusion matrix plot saved to: visualizations/confusion_matrix.png")
    plt.close()

def save_model(model, encoders, feature_names, filepath='models/f1_predictor_model.pkl'):
    """
    Save the trained model and encoders to a pickle file.
    
    Args:
        model: Trained model
        encoders: Dictionary of label encoders
        feature_names: List of feature names
        filepath: Path to save the model
    """
    print("\n" + "="*80)
    print("SAVING MODEL")
    print("="*80)
    
    # Create models directory if it doesn't exist
    os.makedirs('models', exist_ok=True)
    
    # Save model, encoders, and feature names together
    model_data = {
        'model': model,
        'encoders': encoders,
        'feature_names': feature_names
    }
    
    with open(filepath, 'wb') as f:
        pickle.dump(model_data, f)
    
    print(f"Model saved successfully to: {filepath}")
    
    # Print file size
    file_size = os.path.getsize(filepath) / 1024  # KB
    print(f"Model file size: {file_size:.2f} KB")

def main():
    """
    Main function to run the complete training pipeline.
    """
    print("\n" + "="*80)
    print("F1 RACE OUTCOME PREDICTOR - MODEL TRAINING")
    print("="*80)
    
    # Step 1: Load data
    df = load_data()
    
    # Step 2: Explore data
    explore_data(df)
    
    # Step 3: Preprocess data
    X, y, encoders, feature_names = preprocess_data(df)
    
    # Step 4: Train model
    model, X_train, X_test, y_train, y_test = train_model(X, y)
    
    # Step 5: Evaluate model
    evaluate_model(model, X_train, X_test, y_train, y_test, feature_names)
    
    # Step 6: Save model
    save_model(model, encoders, feature_names)
    
    print("\n" + "="*80)
    print("TRAINING PIPELINE COMPLETED SUCCESSFULLY!")
    print("="*80)
    print("\nNext steps:")
    print("1. Run the Streamlit app: streamlit run app.py --server.port 5000")
    print("2. Upload your own dataset to improve predictions")
    print("3. Retrain the model with new data as needed")

if __name__ == "__main__":
    main()
